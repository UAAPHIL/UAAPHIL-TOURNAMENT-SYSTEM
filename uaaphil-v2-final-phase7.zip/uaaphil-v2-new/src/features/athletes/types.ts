export interface AthletesEntity { id: string; }
