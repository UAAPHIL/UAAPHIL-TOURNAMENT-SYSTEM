/**
 * PHASE 5: Auto-advance winner logic - pure, testable
 */
import { BracketMatch } from "../types";

export function advanceWinner(
  matches: BracketMatch[],
  matchId: string,
  winnerId: string
): BracketMatch[] {
  const match = matches.find(m => m.id === matchId);
  if (!match) return matches;
  let updated = matches.map(m => m.id === matchId ? { ...m, winnerId } : m);
  if (match.nextMatchId && match.nextSlot) {
    const winner = match.player1?.id === winnerId ? match.player1 : match.player2;
    if (winner) {
      updated = updated.map(m => {
        if (m.id === match.nextMatchId) {
          return { ...m, [match.nextSlot!]: winner } as BracketMatch;
        }
        return m;
      });
    }
  }
  return updated;
}

export function getPodiumFromBracket(matches: BracketMatch[]) {
  const final = matches.find(m => m.round === "F");
  const bronzeMatch = matches.find(m => m.round === "Bronze");
  if (!final?.winnerId) return null;
  const gold = final.winnerId;
  const silver = final.player1?.id === gold ? final.player2?.id : final.player1?.id;
  const bronze = bronzeMatch?.winnerId;
  if (!gold || !silver || !bronze) return null;
  return { gold, silver, bronze };
}
