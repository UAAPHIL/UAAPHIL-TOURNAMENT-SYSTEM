export interface BracketsEntity { id: string; }
