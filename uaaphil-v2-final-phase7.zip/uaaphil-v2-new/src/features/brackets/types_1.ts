export interface BracketMatch {
  id: string;
  round: "QF"|"SF"|"F"|"Bronze";
  position: number;
  player1?: AthleteSlot;
  player2?: AthleteSlot;
  winnerId?: string;
  nextMatchId?: string;
  nextSlot?: "player1"|"player2";
}
export interface AthleteSlot { id: string; name: string; club: string; }
export interface DivisionBracket { divisionId: string; divisionName: string; matches: BracketMatch[]; }
