import { CertificateData } from "../types";
export function generateCertificateNumber(division: string, place: number): string {
  const year = new Date().getFullYear();
  const divCode = division.replace(/[^A-Z0-9]/g, "").slice(0,4);
  return `UAAPHIL-${year}-${divCode}-${String(place).padStart(3,"0")}`;
}
export function createCertificateData(athleteName: string, club: string, division: string, place: 1|2|3): CertificateData {
  const placeMap = {1:"Champion",2:"1st Runner-up",3:"2nd Runner-up"} as const;
  return {
    id: crypto.randomUUID(),
    athleteName, club, division,
    place: placeMap[place],
    tournamentName: "UAAPHIL National Championship 2026",
    date: new Date().toLocaleDateString("en-PH", {year:"numeric",month:"long",day:"numeric"}),
    certificateNo: generateCertificateNumber(division, place),
  };
}
