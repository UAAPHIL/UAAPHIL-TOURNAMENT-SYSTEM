export interface CertificatesEntity { id: string; }
