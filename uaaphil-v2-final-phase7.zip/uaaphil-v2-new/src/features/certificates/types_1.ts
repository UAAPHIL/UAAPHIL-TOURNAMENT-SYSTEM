export interface CertificateData {
  id: string; athleteName: string; club: string; division: string;
  place: "Champion"|"1st Runner-up"|"2nd Runner-up";
  tournamentName: string; date: string; certificateNo: string;
}
