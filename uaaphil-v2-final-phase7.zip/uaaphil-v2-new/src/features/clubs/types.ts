export interface ClubsEntity { id: string; }
