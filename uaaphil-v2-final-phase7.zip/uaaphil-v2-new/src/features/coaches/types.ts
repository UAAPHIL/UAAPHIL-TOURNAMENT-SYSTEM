export interface CoachesEntity { id: string; }
