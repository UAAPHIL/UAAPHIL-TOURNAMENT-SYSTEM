export interface MatchesEntity { id: string; }
