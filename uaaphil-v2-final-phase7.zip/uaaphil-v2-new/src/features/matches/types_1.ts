export interface MatchRecord {
  id: string; division: string; round: string; player1: string; player2: string;
  winner: string; score: string; status: "completed"|"pending"; date: string;
}
