export interface OfficialsEntity { id: string; }
