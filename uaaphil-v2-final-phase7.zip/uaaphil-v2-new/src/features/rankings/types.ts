export interface RankingsEntity { id: string; }
