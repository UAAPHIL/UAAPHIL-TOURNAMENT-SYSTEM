export interface Medalist { id: string; name: string; club: string; place: 1|2|3; }
export interface PodiumResult { divisionId: string; divisionName: string; gold: Medalist; silver: Medalist; bronze: Medalist[]; }
