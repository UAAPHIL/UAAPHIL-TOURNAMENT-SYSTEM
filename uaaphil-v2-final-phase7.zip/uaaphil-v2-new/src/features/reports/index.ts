// reports feature - foundation only
// TODO: Implement in ARCH 1+
 export {};
