export interface ReportsEntity { id: string; }
