"use client";
import { CertificateData } from "@/features/certificates/types";
export function CertificatePreview({ data }: { data: CertificateData }) {
  return (
    <div className="w-full max-w-[640px] aspect-[1.414/1] bg-[#fafaf8] text-[#1a1a1a] rounded-[12px] p-8 md:p-10 relative overflow-hidden border-[3px] border-[#d4af37]">
      <div className="absolute top-4 left-4 w-12 h-12 border-t-2 border-l-2 border-[#d4af37]" />
      <div className="absolute top-4 right-4 w-12 h-12 border-t-2 border-r-2 border-[#d4af37]" />
      <div className="absolute bottom-4 left-4 w-12 h-12 border-b-2 border-l-2 border-[#d4af37]" />
      <div className="absolute bottom-4 right-4 w-12 h-12 border-b-2 border-r-2 border-[#d4af37]" />
      <div className="text-center space-y-4">
        <p className="text-[10px] tracking-[0.2em] uppercase text-[#8a7a4a]">UAAPHIL Tournament System</p>
        <h1 className="text-[28px] font-serif font-bold tracking-tight">Certificate of Achievement</h1>
        <p className="text-[12px] text-[#6b6b6b]">This certificate is proudly presented to</p>
        <p className="text-[22px] font-semibold font-serif">{data.athleteName}</p>
        <p className="text-[11px] text-[#6b6b6b]">{data.club} • {data.division}</p>
        <div className="py-3"><span className="inline-block px-6 py-1.5 rounded-full bg-[#1a1a1a] text-[#f5e6a8] text-[12px] font-medium tracking-wide">{data.place}</span></div>
        <p className="text-[11px] leading-5 text-[#6b6b6b] max-w-[360px] mx-auto">For outstanding performance at {data.tournamentName} held on {data.date}.</p>
        <div className="flex justify-between pt-8 mt-4 border-t border-dashed border-[#d4af37]/30">
          <div className="text-center"><div className="w-28 h-px bg-[#1a1a1a] mx-auto mb-2" /><p className="text-[9px] uppercase tracking-wider">Tournament Director</p></div>
          <div className="text-center"><p className="text-[9px] font-mono text-[#8a7a4a]">{data.certificateNo}</p><p className="text-[9px] uppercase tracking-wider mt-2">Certificate No.</p></div>
          <div className="text-center"><div className="w-28 h-px bg-[#1a1a1a] mx-auto mb-2" /><p className="text-[9px] uppercase tracking-wider">Head Referee</p></div>
        </div>
      </div>
    </div>
  );
}
