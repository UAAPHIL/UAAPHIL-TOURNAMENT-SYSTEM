"use client";
import { Medalist } from "@/features/rankings/types";
export function PodiumCard({ gold, silver, bronze }: { gold: Medalist; silver: Medalist; bronze: Medalist[] }) {
  return (
    <div className="grid grid-cols-3 gap-4 items-end max-w-[480px] mx-auto">
      <div className="bg-surface border rounded-xl p-4 text-center order-1">
        <div className="h-16 bg-border rounded-t-lg" />
        <p className="mt-3 text-sm font-medium">{silver.name}</p>
        <p className="text-[11px] text-muted">{silver.club}</p>
        <p className="mt-2 text-xs">🥈 2nd</p>
      </div>
      <div className="bg-surface border border-amber-500/30 rounded-xl p-4 text-center order-2 -mt-6 shadow-lg shadow-amber-500/10">
        <div className="h-24 bg-amber-500/20 rounded-t-lg" />
        <p className="mt-3 text-sm font-semibold">{gold.name}</p>
        <p className="text-[11px] text-muted">{gold.club}</p>
        <p className="mt-2 text-xs font-medium text-amber-400">🥇 Champion</p>
      </div>
      <div className="bg-surface border rounded-xl p-4 text-center order-3">
        <div className="h-12 bg-border rounded-t-lg" />
        <p className="mt-3 text-sm font-medium">{bronze[0]?.name}</p>
        <p className="text-[11px] text-muted">{bronze[0]?.club}</p>
        <p className="mt-2 text-xs">🥉 3rd</p>
      </div>
    </div>
  );
}
