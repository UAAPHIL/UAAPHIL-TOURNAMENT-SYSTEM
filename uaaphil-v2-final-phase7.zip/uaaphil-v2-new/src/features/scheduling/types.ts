export interface SchedulingEntity { id: string; }
