export interface ScoringEntity { id: string; }
