export interface TournamentEntity { id: string; }
