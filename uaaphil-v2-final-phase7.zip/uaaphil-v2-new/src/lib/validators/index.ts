import { z } from "zod";

/**
 * PHASE 6: Form foundation - React Hook Form + Zod
 * Reusable validators
 */

export const emailSchema = z.string().email("Invalid email address");
export const passwordSchema = z.string().min(8, "Password must be at least 8 characters");

export const athleteSchema = z.object({
  name: z.string().min(2, "Name is required"),
  club: z.string().min(1, "Club is required"),
  division: z.string().min(1, "Division is required"),
  weight: z.number().min(0).optional(),
});

export const matchResultSchema = z.object({
  matchId: z.string().min(1),
  winnerId: z.string().min(1),
  score: z.string().optional(),
});

export function createValidator<T>(schema: z.ZodSchema<T>) {
  return (data: unknown) => schema.safeParse(data);
}

// Hook Form resolver helper
export type FormErrors<T> = Partial<Record<keyof T, string>>;
