export interface ApiResponse<T> {
  data: T | null;
  error: string | null;
  success: boolean;
}

export interface PaginatedResponse<T> extends ApiResponse<T[]> {
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export type PaginationParams = {
  page: number;
  pageSize: number;
};

export type SortParams = {
  sortBy: string;
  sortOrder: "asc" | "desc";
};

export function createSuccessResponse<T>(data: T): ApiResponse<T> {
  return { data, error: null, success: true };
}

export function createErrorResponse<T>(error: string): ApiResponse<T> {
  return { data: null, error, success: false };
}

export const DEFAULT_PAGE_SIZE = 20;
