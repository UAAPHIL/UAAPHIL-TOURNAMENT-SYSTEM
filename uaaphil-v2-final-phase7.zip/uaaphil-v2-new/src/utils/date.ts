/**
 * Date helpers - pure, no side effects
 */
export function formatDate(date: Date, locale = "en-PH"): string {
  return date.toLocaleDateString(locale, { year: "numeric", month: "long", day: "numeric" });
}

export function formatDateTime(date: Date, locale = "en-PH"): string {
  return date.toLocaleString(locale, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export function formatRelative(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export function now(): Date {
  return new Date();
}

export function isPast(date: Date): boolean {
  return date.getTime() < Date.now();
}
