export class AppError extends Error {
  constructor(message: string, public code?: string, public statusCode?: number) {
    super(message);
    this.name = "AppError";
  }
}

export function formatError(e: unknown): string {
  if (e instanceof AppError) return e.message;
  if (e instanceof Error) return e.message;
  return String(e);
}

export function isAppError(e: unknown): e is AppError {
  return e instanceof AppError;
}
