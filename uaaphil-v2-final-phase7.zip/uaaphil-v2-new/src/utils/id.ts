export function generateId(): string {
  return Math.random().toString(36).slice(2, 10);
}

export function generateUuid(): string {
  return crypto.randomUUID();
}

export function generateCertificateNo(division: string, place: number): string {
  const year = new Date().getFullYear();
  const code = division.replace(/[^A-Z0-9]/g, "").slice(0, 4);
  return `UAAPHIL-${year}-${code}-${String(place).padStart(3, "0")}`;
}
