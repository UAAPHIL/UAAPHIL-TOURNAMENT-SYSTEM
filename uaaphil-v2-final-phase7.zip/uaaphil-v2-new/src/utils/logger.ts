type LogLevel = "info" | "warn" | "error" | "debug";

interface LogMeta { [key: string]: unknown; }

function log(level: LogLevel, message: string, meta?: LogMeta) {
  if (process.env.NODE_ENV === "production" && level === "debug") return;
  const prefix = `[${level.toUpperCase()}]`;
  const fn = level === "error" ? console.error : level === "warn" ? console.warn : console.log;
  fn(`${prefix} ${message}`, meta ?? "");
}

export const logger = {
  info: (msg: string, meta?: LogMeta) => log("info", msg, meta),
  warn: (msg: string, meta?: LogMeta) => log("warn", msg, meta),
  error: (msg: string, meta?: LogMeta) => log("error", msg, meta),
  debug: (msg: string, meta?: LogMeta) => log("debug", msg, meta),
};
